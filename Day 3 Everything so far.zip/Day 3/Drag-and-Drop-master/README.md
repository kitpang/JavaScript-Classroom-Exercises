# Drag-and-Drop
This folder contains materials and resources for HTML5 Drag and Drop API classroom training
