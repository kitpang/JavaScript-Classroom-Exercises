# JSON-and-AJAX-
This repository is a case study for the JSON and AJAX classroom training
