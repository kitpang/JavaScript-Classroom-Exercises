# JavaScript
This is my classroom training resources for JavaScript week
