/* This is my OOP practice JS file */

/*function personalDetails(name, city) {

    console.log("My name is " + name +
        " and I live in " + city + ".");

    document.getElementById("display").innerHTML = "My name is " + name + " and I live in " + city + ".";

}

personalDetails("Sajin", "London");
personalDetails("Nav", "Lewisham");*/

// Let's create an object to structure our data.

/*var person = {

    name: "Max",
    city: "Grove Park",
    personData: function () {


        // MN: this.name works better than person.name
        // since there could be a GLOBAL variable named "person"
        // we may or may not be aware of and the function will /get
       //  confused
       // console.log("My name is " + person.name +
            " and I live in " + person.city + ".");

        document.getElementById("display").innerHTML = "My name is " + person.name + " and I live in " + person.city + ".";

    }

};

/*person.personData();

console.log(person.name);
console.log(person.city);*/

//Now we are going to build our CONSTRUCTOR

var ourPeople = [];

function People(fullName, location) {

    this.name = fullName;
    this.city = location;

    ourPeople.push([this.name,
                    this.city]);


    this.personData = function () {

        console.log("My name is " + this.name +
            " and I live in " + this.city + ".");

        document.getElementById("display").innerHTML += "My name is " + this.name + " and I live in " + this.city + "." + "<br>";
    }

}

var Panna = new People("Panna G", "Paris");
var Peter = new People("Peter M", "Tokyo");

Panna.personData();
Peter.personData();

console.log(ourPeople[1][1]);

// Day 3 --------------------------------------------------------------------------------------------------------------------------------------

/*var car = {
    model: "Toyota - Yaris",
    price: "£12495",
    fuel: "Petrol",
    "engine": "1.5-liter 7NR-FE"
};

//MN: car.engine is called Object Notation
console.log(car.engine);

var f1Drivers = ["Lewis", "Kimi", "Alonso"];

//MN: displays "Alonso" on the console log when f1Drivers[2]
console.log(f1Drivers[2]);*/


var f1 = {
    "data": [

        {
            "car": "Mercedes",
            "driver": "Lewis",
            "wins": 2
        },
        {
            "circuit": "Monaco",
            "pointSystem": [
                {
                    "firstPlace": 25,
                    "secondPlace": 18,
                    "thirdPlace": 15
                }

            ],
            "teams": 11
        }
    ]
}

console.log(f1.data[1].pointSystem[0].thirdPlace);





